firstName = input("Enter the first name: ")
mi = input("Enter the middle name initial: ")
lastName = input("Enter the last name: ")
print("The name is", firstName, mi, lastName)